# Simple Network Monitoring Tool
# Author: Wesley Attram

import os
import platform

def ping_host(host):
    param = "-n 1" if platform.system().lower() == "windows" else "-c 1"
    response = os.system(f"ping {param} {host} > nul 2>&1")
    return "Online" if response == 0 else "Offline"

if __name__ == "__main__":
    host = input("Enter host to check: ")
    print(f"{host} is {ping_host(host)}")
